(window.webpackJsonp=window.webpackJsonp||[]).push([[6],{RorI:function(N,x,s){"use strict";s.d(x,"a",function(){return ue}),s.d(x,"b",function(){return se});var j=s("Znn+"),P=s("ZTPi"),f=s("q1tI"),c=s.n(f),S=s("Y+p1"),L=s.n(S);function A(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),n.push.apply(n,a)}return n}function D(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]!=null?arguments[t]:{};t%2?A(Object(n),!0).forEach(function(a){H(e,a,n[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):A(Object(n)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(n,a))})}return e}function H(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function q(e,t){if(e==null)return{};var n={},a=Object.keys(e),r,o;for(o=0;o<a.length;o++)r=a[o],!(t.indexOf(r)>=0)&&(n[r]=e[r]);return n}function U(e,t){if(e==null)return{};var n=q(e,t),a,r;if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);for(r=0;r<o.length;r++)a=o[r],!(t.indexOf(a)>=0)&&(!Object.prototype.propertyIsEnumerable.call(e,a)||(n[a]=e[a]))}return n}function w(e,t){return F(e)||X(e,t)||K(e,t)||$()}function W(e){return z(e)||J(e)||K(e)||Z()}function z(e){if(Array.isArray(e))return I(e)}function F(e){if(Array.isArray(e))return e}function J(e){if(typeof Symbol!="undefined"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function X(e,t){var n=e==null?null:typeof Symbol!="undefined"&&e[Symbol.iterator]||e["@@iterator"];if(n!=null){var a=[],r=!0,o=!1,i,l;try{for(n=n.call(e);!(r=(i=n.next()).done)&&(a.push(i.value),!(t&&a.length===t));r=!0);}catch(b){o=!0,l=b}finally{try{!r&&n.return!=null&&n.return()}finally{if(o)throw l}}return a}}function K(e,t){if(!!e){if(typeof e=="string")return I(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if(n==="Object"&&e.constructor&&(n=e.constructor.name),n==="Map"||n==="Set")return Array.from(e);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return I(e,t)}}function I(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,a=new Array(t);n<t;n++)a[n]=e[n];return a}function Z(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function $(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var T;(function(e){e[e.UPDATE_TABS=0]="UPDATE_TABS"})(T||(T={}));var Y={tabs:[],dispatch:function(){}};function Q(e,t){var n=t.type,a=t.payload;switch(n){case T.UPDATE_TABS:return D(D({},e),{},{tabs:a});default:return e}}var M=c.a.createContext(Y);function V(e){var t=e.children,n=Object(f.useReducer)(Q,Y),a=w(n,2),r=a[0],o=a[1];return r.dispatch=o,c.a.createElement(M.Provider,{value:r}," ",t," ")}var ee=["key","search"],te=["key","search"];function y(e){var t=e.pathname,n=e.search,a=e.hash;return"".concat(t).concat(n).concat(a)}function ne(e,t){return e===y(t)}function ae(e,t){var n=e.key,a=e.search,r=U(e,ee),o=t.key,i=t.search,l=U(t,te);if(r.query)for(var b in r.query)r.query[b]=r.query[b].toString();if(l.query)for(var g in l.query)l.query[g]=l.query[g].toString();return!L()(r,l)}function re(e,t){t===void 0&&(t={});var n=t.insertAt;if(!(!e||typeof document=="undefined")){var a=document.head||document.getElementsByTagName("head")[0],r=document.createElement("style");r.type="text/css",n==="top"&&a.firstChild?a.insertBefore(r,a.firstChild):a.appendChild(r),r.styleSheet?r.styleSheet.cssText=e:r.appendChild(document.createTextNode(e))}}var oe=`.ant-layout-content .ant-page-tabs {
  margin-top: -24px;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list {
  overflow: visible;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav {
  margin-bottom: 24px;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav > .ant-tabs-nav-wrap {
  margin-left: -24px;
  margin-right: -24px;
  background-color: #fff;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs {
  margin-top: 0;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav {
  margin-bottom: unset;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav > .ant-tabs-nav-wrap {
  margin-left: 0;
  margin-right: 0;
}
.ant-page-tabs .ant-tabs-nav {
  width: 100%;
  background-color: #fff;
}
.index_contextMenu__GaY68 {
  position: fixed;
  display: none;
  background-color: rgba(255, 255, 255, 0.98);
  border: 1px solid #ccc;
  list-style: none;
  padding: 4px 0;
  border-radius: 4px;
  box-shadow: 0px 2px 6px 2px #ddd;
}
.index_contextMenu__GaY68 li {
  padding: 8px 12px;
  border-bottom: 1px solid #f0f2f5;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  transition: all 0.1s;
}
.index_contextMenu__GaY68 li:last-child {
  border-bottom: none;
}
.index_contextMenu__GaY68 li:hover {
  cursor: pointer;
  background-color: #0170fe;
  color: #fff;
}
.index_contextMenu__GaY68 li:active {
  background-color: rgba(255, 255, 255, 0.6);
  color: #000;
}
.index_show__HGFYh {
  display: block;
}
.index_tabLabel__3YS8K {
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}
`,R={contextMenu:"index_contextMenu__GaY68",show:"index_show__HGFYh",tabLabel:"index_tabLabel__3YS8K"};re(oe);var ie=function(t){var n=t.tab,a=t.position,r=t.history,o=t.handleTabClose,i=t.menuLabels,l=Object(f.useContext)(M),b=l.tabs,g=l.dispatch,h=function(_){g({type:T.UPDATE_TABS,payload:_})},u=function(){!n||o(y(n.location),"remove")},E=function(){if(!!n){var _=b.indexOf(n);_<0||(r.push(n.location),h(b.slice(0,_+1)))}},p=function(){r.push("/"),h([])};return c.a.createElement("ul",{className:"".concat(R.contextMenu," ").concat(n&&R.show),style:{left:a==null?void 0:a.x,top:a==null?void 0:a.y}},c.a.createElement("li",{onClick:u},(i==null?void 0:i.closeTab)||"Close Tab"),c.a.createElement("li",{onClick:E},(i==null?void 0:i.closeRightTabs)||"Close Tabs to The Right"),c.a.createElement("li",{onClick:p},(i==null?void 0:i.closeAllTabs)||"Close All Tabs"))},le=P.a.TabPane,ce=function(t){var n=Object(f.useState)(),a=w(n,2),r=a[0],o=a[1],i=Object(f.useState)(),l=w(i,2),b=l[0],g=l[1],h=Object(f.useContext)(M),u=h.tabs,E=h.dispatch,p=t.location,C=t.defaultChildren,_=t.history,de=t.contextMenuLabels,fe=Object(f.useMemo)(function(){return u.some(function(v){return y(v.location)===y(p)})},[p]),be=function(d){var m=u.find(function(O){return y(O.location)===d});m&&_.push(m.location)},k=function(d,m){if(m==="remove"){var O=u.findIndex(function(ye){return y(ye.location)===d});if(O<0)return;var B;ne(d,p)&&(B=u[O+1]||u[O-1]||{location:"/"}),B&&_.push(B.location);var G=W(u);G.splice(O,1),E({type:T.UPDATE_TABS,payload:G})}},he=function(d,m){d.preventDefault(),o(m),g({x:d.clientX,y:d.clientY})},ve=function(){function d(){o(void 0)}return document.addEventListener("click",d),function(){document.removeEventListener("click",d)}};return Object(f.useEffect)(ve,[]),c.a.createElement("div",{className:"ant-page-tabs"},c.a.createElement(P.a,{className:"ant-page-tab-list",hideAdd:!0,type:"editable-card",onChange:be,onEdit:k,activeKey:y(p)},u.map(function(v){return c.a.createElement(le,{tab:c.a.createElement("span",{onContextMenu:function(m){he(m,v)},className:R.tabLabel},v.route.tabLocalName||v.route.name),key:y(v.location)},v.children)})),!fe&&C,c.a.createElement(ie,{tab:r,position:b,history:_,handleTabClose:k,menuLabels:de}))},se=function(t){var n=t.children,a=t.location,r=t.history,o=t.contextMenuLabels;return c.a.createElement(V,null,c.a.createElement(ce,{history:r,location:a,defaultChildren:n,contextMenuLabels:o}))},ue=function(t){var n=Object(f.useContext)(M),a=n.tabs,r=n.dispatch,o=t.children,i=t.route,l=t.location,b=function(){var h=W(a),u=h.find(function(p){return p.route.path===i.path}),E={route:i,location:l,children:o};u?ae(u.location,l)&&h.splice(h.indexOf(u),1,E):h.push(E),r({type:T.UPDATE_TABS,payload:h})};return Object(f.useEffect)(b,[]),null}},"qdX+":function(N,x,s){"use strict";s.r(x);var j=s("k1fw"),P=s("q1tI"),f=s.n(P),c=s("RorI"),S="JT+q",L={closeTab:"\u5173\u95ED\u6807\u7B7E",closeRightTabs:"\u5173\u95ED\u53F3\u4FA7\u6807\u7B7E",closeAllTabs:"\u5173\u95ED\u6240\u6709\u6807\u7B7E"};x.default=function(A){var D=A.children;return Object(P.createElement)(c.b,Object(j.a)(Object(j.a)({},A),{},{contextMenuLabels:L,key:"".concat(S,"11")}))}}}]);
