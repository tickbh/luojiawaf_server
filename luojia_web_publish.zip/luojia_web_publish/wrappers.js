(window.webpackJsonp=window.webpackJsonp||[]).push([[27],{"2kbO":function(Y,O,d){"use strict";d.r(O);var D=d("RorI"),P="HHN0";O.default=D.a},RorI:function(Y,O,d){"use strict";d.d(O,"a",function(){return st}),d.d(O,"b",function(){return ut});var D=d("Znn+"),P=d("ZTPi"),v=d("q1tI"),c=d.n(v),G=d("Y+p1"),N=d.n(G);function w(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(t);e&&(a=a.filter(function(r){return Object.getOwnPropertyDescriptor(t,r).enumerable})),n.push.apply(n,a)}return n}function I(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?w(Object(n),!0).forEach(function(a){H(t,a,n[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):w(Object(n)).forEach(function(a){Object.defineProperty(t,a,Object.getOwnPropertyDescriptor(n,a))})}return t}function H(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function q(t,e){if(t==null)return{};var n={},a=Object.keys(t),r,o;for(o=0;o<a.length;o++)r=a[o],!(e.indexOf(r)>=0)&&(n[r]=t[r]);return n}function R(t,e){if(t==null)return{};var n=q(t,e),a,r;if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(t);for(r=0;r<o.length;r++)a=o[r],!(e.indexOf(a)>=0)&&(!Object.prototype.propertyIsEnumerable.call(t,a)||(n[a]=t[a]))}return n}function M(t,e){return F(t)||Z(t,e)||U(t,e)||$()}function B(t){return z(t)||J(t)||U(t)||X()}function z(t){if(Array.isArray(t))return S(t)}function F(t){if(Array.isArray(t))return t}function J(t){if(typeof Symbol!="undefined"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function Z(t,e){var n=t==null?null:typeof Symbol!="undefined"&&t[Symbol.iterator]||t["@@iterator"];if(n!=null){var a=[],r=!0,o=!1,i,l;try{for(n=n.call(t);!(r=(i=n.next()).done)&&(a.push(i.value),!(e&&a.length===e));r=!0);}catch(f){o=!0,l=f}finally{try{!r&&n.return!=null&&n.return()}finally{if(o)throw l}}return a}}function U(t,e){if(!!t){if(typeof t=="string")return S(t,e);var n=Object.prototype.toString.call(t).slice(8,-1);if(n==="Object"&&t.constructor&&(n=t.constructor.name),n==="Map"||n==="Set")return Array.from(t);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return S(t,e)}}function S(t,e){(e==null||e>t.length)&&(e=t.length);for(var n=0,a=new Array(e);n<e;n++)a[n]=t[n];return a}function X(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function $(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var T;(function(t){t[t.UPDATE_TABS=0]="UPDATE_TABS"})(T||(T={}));var k={tabs:[],dispatch:function(){}};function Q(t,e){var n=e.type,a=e.payload;switch(n){case T.UPDATE_TABS:return I(I({},t),{},{tabs:a});default:return t}}var A=c.a.createContext(k);function V(t){var e=t.children,n=Object(v.useReducer)(Q,k),a=M(n,2),r=a[0],o=a[1];return r.dispatch=o,c.a.createElement(A.Provider,{value:r}," ",e," ")}var tt=["key","search"],et=["key","search"];function y(t){var e=t.pathname,n=t.search,a=t.hash;return"".concat(e).concat(n).concat(a)}function nt(t,e){return t===y(e)}function at(t,e){var n=t.key,a=t.search,r=R(t,tt),o=e.key,i=e.search,l=R(e,et);if(r.query)for(var f in r.query)r.query[f]=r.query[f].toString();if(l.query)for(var g in l.query)l.query[g]=l.query[g].toString();return!N()(r,l)}function rt(t,e){e===void 0&&(e={});var n=e.insertAt;if(!(!t||typeof document=="undefined")){var a=document.head||document.getElementsByTagName("head")[0],r=document.createElement("style");r.type="text/css",n==="top"&&a.firstChild?a.insertBefore(r,a.firstChild):a.appendChild(r),r.styleSheet?r.styleSheet.cssText=t:r.appendChild(document.createTextNode(t))}}var ot=`.ant-layout-content .ant-page-tabs {
  margin-top: -24px;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list {
  overflow: visible;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav {
  margin-bottom: 24px;
}
.ant-layout-content .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav > .ant-tabs-nav-wrap {
  margin-left: -24px;
  margin-right: -24px;
  background-color: #fff;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs {
  margin-top: 0;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav {
  margin-bottom: unset;
}
.ant-pro-basicLayout-content-disable-margin .ant-page-tabs .ant-page-tab-list > .ant-tabs-nav > .ant-tabs-nav-wrap {
  margin-left: 0;
  margin-right: 0;
}
.ant-page-tabs .ant-tabs-nav {
  width: 100%;
  background-color: #fff;
}
.index_contextMenu__GaY68 {
  position: fixed;
  display: none;
  background-color: rgba(255, 255, 255, 0.98);
  border: 1px solid #ccc;
  list-style: none;
  padding: 4px 0;
  border-radius: 4px;
  box-shadow: 0px 2px 6px 2px #ddd;
}
.index_contextMenu__GaY68 li {
  padding: 8px 12px;
  border-bottom: 1px solid #f0f2f5;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  transition: all 0.1s;
}
.index_contextMenu__GaY68 li:last-child {
  border-bottom: none;
}
.index_contextMenu__GaY68 li:hover {
  cursor: pointer;
  background-color: #0170fe;
  color: #fff;
}
.index_contextMenu__GaY68 li:active {
  background-color: rgba(255, 255, 255, 0.6);
  color: #000;
}
.index_show__HGFYh {
  display: block;
}
.index_tabLabel__3YS8K {
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}
`,j={contextMenu:"index_contextMenu__GaY68",show:"index_show__HGFYh",tabLabel:"index_tabLabel__3YS8K"};rt(ot);var it=function(e){var n=e.tab,a=e.position,r=e.history,o=e.handleTabClose,i=e.menuLabels,l=Object(v.useContext)(A),f=l.tabs,g=l.dispatch,b=function(m){g({type:T.UPDATE_TABS,payload:m})},u=function(){!n||o(y(n.location),"remove")},x=function(){if(!!n){var m=f.indexOf(n);m<0||(r.push(n.location),b(f.slice(0,m+1)))}},p=function(){r.push("/"),b([])};return c.a.createElement("ul",{className:"".concat(j.contextMenu," ").concat(n&&j.show),style:{left:a==null?void 0:a.x,top:a==null?void 0:a.y}},c.a.createElement("li",{onClick:u},(i==null?void 0:i.closeTab)||"Close Tab"),c.a.createElement("li",{onClick:x},(i==null?void 0:i.closeRightTabs)||"Close Tabs to The Right"),c.a.createElement("li",{onClick:p},(i==null?void 0:i.closeAllTabs)||"Close All Tabs"))},lt=P.a.TabPane,ct=function(e){var n=Object(v.useState)(),a=M(n,2),r=a[0],o=a[1],i=Object(v.useState)(),l=M(i,2),f=l[0],g=l[1],b=Object(v.useContext)(A),u=b.tabs,x=b.dispatch,p=e.location,C=e.defaultChildren,m=e.history,dt=e.contextMenuLabels,ft=Object(v.useMemo)(function(){return u.some(function(h){return y(h.location)===y(p)})},[p]),bt=function(s){var _=u.find(function(E){return y(E.location)===s});_&&m.push(_.location)},W=function(s,_){if(_==="remove"){var E=u.findIndex(function(yt){return y(yt.location)===s});if(E<0)return;var L;nt(s,p)&&(L=u[E+1]||u[E-1]||{location:"/"}),L&&m.push(L.location);var K=B(u);K.splice(E,1),x({type:T.UPDATE_TABS,payload:K})}},ht=function(s,_){s.preventDefault(),o(_),g({x:s.clientX,y:s.clientY})},vt=function(){function s(){o(void 0)}return document.addEventListener("click",s),function(){document.removeEventListener("click",s)}};return Object(v.useEffect)(vt,[]),c.a.createElement("div",{className:"ant-page-tabs"},c.a.createElement(P.a,{className:"ant-page-tab-list",hideAdd:!0,type:"editable-card",onChange:bt,onEdit:W,activeKey:y(p)},u.map(function(h){return c.a.createElement(lt,{tab:c.a.createElement("span",{onContextMenu:function(_){ht(_,h)},className:j.tabLabel},h.route.tabLocalName||h.route.name),key:y(h.location)},h.children)})),!ft&&C,c.a.createElement(it,{tab:r,position:f,history:m,handleTabClose:W,menuLabels:dt}))},ut=function(e){var n=e.children,a=e.location,r=e.history,o=e.contextMenuLabels;return c.a.createElement(V,null,c.a.createElement(ct,{history:r,location:a,defaultChildren:n,contextMenuLabels:o}))},st=function(e){var n=Object(v.useContext)(A),a=n.tabs,r=n.dispatch,o=e.children,i=e.route,l=e.location,f=function(){var b=B(a),u=b.find(function(p){return p.route.path===i.path}),x={route:i,location:l,children:o};u?at(u.location,l)&&b.splice(b.indexOf(u),1,x):b.push(x),r({type:T.UPDATE_TABS,payload:b})};return Object(v.useEffect)(f,[]),null}}}]);
